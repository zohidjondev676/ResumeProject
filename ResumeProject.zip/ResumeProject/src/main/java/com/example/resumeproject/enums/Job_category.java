package com.example.resumeproject.enums;

public enum Job_category {
    JAVA_BACKEND, PHYTON_BACKEND, FRONTED, NODJES, PHP, DOTNET,
}
