package com.example.resumeproject.enums;

public enum User_type {
    ADMIN, USER
}
