package com.example.resumeproject.user;

import org.springframework.stereotype.Service;

@Service
public class UserService {

    private UserRepository userRepository;


}
