package com.example.resumeproject.enums;

public enum Account_type {
    ACTIVE, PASSIVE
}
