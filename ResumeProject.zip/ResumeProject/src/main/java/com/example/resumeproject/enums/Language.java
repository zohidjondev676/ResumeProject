package com.example.resumeproject.enums;

public enum Language {
    UZBEK, RUSSIA, ENGLISH
}
