package com.example.resumeproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResumeProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(ResumeProjectApplication.class, args);
    }

}
