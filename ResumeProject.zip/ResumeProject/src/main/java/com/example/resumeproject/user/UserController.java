package com.example.resumeproject.user;

import org.springframework.stereotype.Controller;

@Controller

public class UserController extends UserService {



}
